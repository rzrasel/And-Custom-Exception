package com.rz.rzcontentprovider;

import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ActSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_splash);
        //String URL = "content://rz.DataProvider";
        //Uri contentUri = Uri.parse(URL);
        Uri contentUri = DataContract.buildUriWithInfoName("Rasel");
        System.out.println(contentUri);
        Cursor cursor = managedQuery(contentUri, null, null, null, "name");
        System.out.println("COUNT: " + cursor.getCount());
        /*if (cursor.moveToFirst()) {
            do {
                *//*Toast.makeText(this,
                        c.getString(c.getColumnIndex(StudentsProvider._ID)) +
                                ", " + c.getString(c.getColumnIndex(StudentsProvider.NAME)) +
                                ", " + c.getString(c.getColumnIndex(StudentsProvider.GRADE)),
                        Toast.LENGTH_SHORT).show();*//*
         *//*System.out.println("DATA: " + cursor.getString(cursor.getColumnIndex("name_column")));
                System.out.println("DATA: " + cursor.getString(cursor.getColumnIndex("age_column")));*//*
                System.out.println("DATA: " + cursor.getString(0));
                System.out.println("DATA: " + cursor.getString(1));
            } while (cursor.moveToNext());
        }*/
        if (cursor.moveToFirst()) {
            do {
                System.out.println("DATA: " + cursor.getString(0));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
    }
}
//https://www.codexpedia.com/android/android-content-provider-example/
//https://stackoverflow.com/questions/14368867/permission-denial-opening-provider
/*
///personal_info?name=Rasel
Uri contentUri = Uri.parse("content://com.rz.data_provider/personal_info?name=Rasel");
System.out.println(contentUri);
//Cursor cursor = managedQuery(contentUri, null, null, null, "name");
Cursor cursor = getContentResolver().query(contentUri, null, null, null, "name");
System.out.println("COUNT: " + cursor.getCount());
if (cursor.moveToFirst()) {
    do {
        System.out.println("DATA: " + cursor.getString(0));
    }
    while (cursor.moveToNext());
}
cursor.close();
*/
