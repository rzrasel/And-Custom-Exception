package com.rz.rzcontentprovider;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class PersonalInfoDataHelper extends SQLiteDataManager {
    private SQLiteDBCopyHelper sqLiteDBCopyHelper = null;

    public PersonalInfoDataHelper(Context argContext) {
        super(argContext);
        super.setDbVersion(1)
                .setDbDirectoryName("/db/")
                .setDbFileName("db_content_provider.sqlite3");
    }

    public Cursor getDataByAge(String argAge) {
        /*argSQLiteDatabase.beginTransaction();
        Cursor cursor = argSQLiteDatabase.rawQuery(query, null);*/
        String sqlQuery = "SELECT " + DataContract.NAME_COLUMN + " FROM " + DataContract.TABLE_NAME + " WHERE " + DataContract.AGE_COLUMN + "='" + argAge + "';";
        sqLiteDBCopyHelper = super.openDatabase();
        Cursor cursor = sqLiteDBCopyHelper.getSqlQueryResults(sqlQuery);
        return cursor;
    }

    public Cursor getDataByName(String argName) {
        String sqlQuery = "SELECT " + DataContract.AGE_COLUMN + " FROM " + DataContract.TABLE_NAME + " WHERE " + DataContract.NAME_COLUMN + "='" + argName + "';";
        sqLiteDBCopyHelper = super.openDatabase();
        Cursor cursor = sqLiteDBCopyHelper.getSqlQueryResults(sqlQuery);
        return cursor;
    }
}