package com.rz.rzcontentprovider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

import static com.rz.rzcontentprovider.DataContract.AGE;
import static com.rz.rzcontentprovider.DataContract.CONTENT_AUTHORITY;
import static com.rz.rzcontentprovider.DataContract.NAME;
import static com.rz.rzcontentprovider.DataContract.PATH_INFO;

public class RzTestData extends ContentProvider {
    private PersonalInfoDataHelper personalInfoDataHelper;

    public static UriMatcher buildUriMatcher() {
        UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(CONTENT_AUTHORITY, PATH_INFO, NAME);
        uriMatcher.addURI(CONTENT_AUTHORITY, PATH_INFO + "?name=" + "/*", NAME);
        uriMatcher.addURI(CONTENT_AUTHORITY, PATH_INFO + "?age=" + "/*", AGE);
        return uriMatcher;
    }

    @Override
    public boolean onCreate() {
        personalInfoDataHelper = new PersonalInfoDataHelper(getContext());
        return true;
    }

    @Override
    public String getType(Uri argUri) {
        UriMatcher uriMatcher = buildUriMatcher();
        switch (uriMatcher.match(argUri)) {
            case NAME:
                return CONTENT_AUTHORITY + "/personal_info?name";

            case AGE:
                return CONTENT_AUTHORITY + "/personal_info?age";
            default:
                throw new UnsupportedOperationException("Cannot find any type listed in URI : " + argUri);
        }
    }

    @Override
    public Cursor query(Uri argUri, String[] argProjection, String argSelection, String[] argSelectionArgs, String argSortOrder) {
        Cursor cursor = null;
        UriMatcher uriMatcher = buildUriMatcher();

        switch (uriMatcher.match(argUri)) {
            case NAME:
                //cursor = mDataHelper.getDataByNames(mDataHelper.getReadableDatabase(), argUri.getQueryParameter("age"));
                cursor = personalInfoDataHelper.getDataByName(argUri.getQueryParameter("name"));
                break;
            case AGE:
                //cursor = personalInfoDataHelper.getDataByAge(personalInfoDataHelper.getReadableDatabase(), argUri.getQueryParameter("name"));
                cursor = personalInfoDataHelper.getDataByAge(argUri.getQueryParameter("name"));
                break;
            default:
                throw new UnsupportedOperationException("Cannot execute query, URI mismatch : " + argUri);
        }
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(Uri uri, String s, String[] strings) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String s, String[] strings) {
        return 0;
    }
}
