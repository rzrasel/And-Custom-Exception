package com.rz.appdatareceiver;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ActStartIt extends AppCompatActivity {
    private Activity activity;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_start_it);
        activity = this;
        context = this;
        Bundle bundleExtras = getIntent().getExtras();
        if (bundleExtras != null) {
            String id = bundleExtras.getString("id");
            String title = bundleExtras.getString("title");
            System.out.println("ID_VALUE: " + id);
            System.out.println("TITLE_VALUE: " + title);
            onWriteFile(id, title);
        }
    }

    private void onWriteFile(String argId, String argTitle) {
        File filePath = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator);
        System.out.println("FILE_PATH: " + filePath);
        filePath = new File(filePath, "highscore.txt");
        System.out.println("FILE_PATH: " + filePath);
        try {
            String fileData = argId + "\n" + argTitle;
            BufferedWriter bw = new BufferedWriter(new FileWriter(filePath));
            bw.write(String.valueOf(fileData));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
