package com.rz.appdatareceiver;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ActSplash extends AppCompatActivity {
    private Activity activity;
    private Context context;
    private static final int REQUEST_WRITE_PERMISSION = 786;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_splash);
        activity = this;
        context = this;
        /*String className = context.getPackageName() + ".ActAnotherAppDataReceiver";
        System.out.println("CLASS NAME: " + className);
        Intent intent = new Intent(className);
        intent.setPackage(context.getPackageName());//the destination packageName
        intent.putExtra("id", "100");
        intent.putExtra("title", "Receive data from another application");
        startActivity(intent);*/
        requestPermission();
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_PERMISSION);
        } else {
            onRedirectWindow();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_WRITE_PERMISSION && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            onRedirectWindow();
        }
    }

    private void onRedirectWindow() {
        Intent intent = new Intent(context, ActAnotherAppDataReceiver.class);
        intent.putExtra("id", "100");
        intent.putExtra("title", "Receive data from another application");
        startActivity(intent);
    }
}
