package com.rz.appdatareceiver;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ActAnotherAppDataReceiver extends AppCompatActivity {
    private Activity activity;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_another_app_data_receiver);
        activity = this;
        context = this;
        Bundle bundleExtras = getIntent().getExtras();
        if (bundleExtras != null) {
            String id = bundleExtras.getString("id");
            String title = bundleExtras.getString("title");
            System.out.println("ID_VALUE: " + id);
            System.out.println("TITLE_VALUE: " + title);
            onWriteFile(id, title);
        }
    }

    private void onWriteFile(String argId, String argTitle) {
        File filePath = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator);
        System.out.println("FILE_PATH: " + filePath);
        filePath = new File(filePath, "highscore.txt");
        System.out.println("FILE_PATH: " + filePath);
        try {
            String fileData = argId + "\n" + argTitle;
            BufferedWriter bw = new BufferedWriter(new FileWriter(filePath));
            bw.write(String.valueOf(fileData));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int readHighScore() {
        /*try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            try {
                highScore = Integer.parseInt(br.readLine());
                br.close();
            } catch (NumberFormatException | IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            try {
                file.createNewFile();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
            e.printStackTrace();
        }
        return highScore;*/
        return 0;
    }

    public void writeHighScore(int highestScore) {
        /*try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));
            bw.write(String.valueOf(highestScore));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}
