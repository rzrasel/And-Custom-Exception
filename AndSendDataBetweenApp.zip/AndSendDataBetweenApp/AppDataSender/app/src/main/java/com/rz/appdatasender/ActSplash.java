package com.rz.appdatasender;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ActSplash extends AppCompatActivity {
    private Activity activity;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_splash);
        activity = this;
        context = this;
        /*String appName = "App Data Receiver";
        String packageName = "com.rz.appdatareceiver";
        String className = packageName + "." + appName + ".ActAnotherAppDataReceiver";
        System.out.println("CLASS NAME: " + className);*/
        /*Intent intent = new Intent(className);
        intent.setPackage(packageName);//the destination packageName*/
       /* Intent intent = new Intent(className);
        intent.putExtra("id", "500");
        intent.putExtra("title", "Send data from another application");
        startActivity(intent);*/
        /*Intent intent = new Intent(Intent.ACTION_SEND);
        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        System.out.println(apps.toString());*/
        okStart();
    }

    private int PHOTO_REQUEST_CODE = 888;

    private void okStart() {
        String packageName = "com.rz.appdatareceiver";
        String className = packageName + ".ActStartIt";
        Intent takePictureIntent = new Intent(className);
        takePictureIntent.putExtra("id", "8000");
        takePictureIntent.putExtra("title", "This is second my text to send using my key.");
        startActivityForResult(takePictureIntent, PHOTO_REQUEST_CODE);
        /*String packageName = "com.rz.appdatareceiver";
        String className = packageName + ".ActStartIt";
        Intent inent = new Intent(className);
        inent.putExtra("id", "8000");
        inent.putExtra("title", "This is second my text to send using my key.");
        startActivity(inent);*/
        //http://hmkcode.com/android-start-another-activity-of-another-application/
    }

    private void okSendData() {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
        sendIntent.putExtra("id", "5000");
        sendIntent.putExtra("title", "This is second my text to send using my key.");
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, "Send"));
        //http://www.coderzheaven.com/2013/04/01/send-data-individual-applications-android/
    }
}
//http://programmerguru.com/android-tutorial/how-to-send-simple-data-to-other-apps/
//https://stackoverflow.com/questions/10407159/how-to-manage-startactivityforresult-on-android