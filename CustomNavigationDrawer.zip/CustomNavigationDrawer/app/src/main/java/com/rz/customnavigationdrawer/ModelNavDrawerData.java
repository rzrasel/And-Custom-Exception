package com.rz.customnavigationdrawer;

public class ModelNavDrawerData {
    private String navTitle;

    public ModelNavDrawerData(String argNavTitle) {
        this.navTitle = argNavTitle;
    }

    public String getNavTitle() {
        return this.navTitle;
    }

    public void setNavTitle(String argNavTitle) {
        this.navTitle = argNavTitle;
    }
}
